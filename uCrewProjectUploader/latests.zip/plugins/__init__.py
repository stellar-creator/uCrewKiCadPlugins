from .ucp_uploader import uCrewProjectsUploader
uCrewProjectsUploader().register()