import pcbnew, os, sys

from .ucp_uploader import uCrewProjectsUploader

uCrewProjectsUploader().register()